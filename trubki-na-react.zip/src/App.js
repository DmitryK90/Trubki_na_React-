import BlockTubesContainer from "./components/BlockMain/BlockTubesContainer";
import ChoiceLengSection from "./components/ChoiceLengSection/ChoiceLengSection";
import ResultSection from "./components/ResultSection/ResultSection";
import BlockAdd from "./components/BlockAdd/BlockAdd";
import "./styles.css";

export default function App() {
  return (
    <div className="wrapper">
      <div className="mainMenu">
        <BlockTubesContainer />
        {/* {если создан блок 1, то создать второй} */}
      </div>
      <hr className="hr"></hr>
      <ChoiceLengSection />
      <ResultSection />
      <hr className="hr"></hr>
    </div>
  );
}

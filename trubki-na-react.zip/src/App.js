import BlockTubesContainer from "./components/BlockMain/BlockTubesContainer";
import ChoiceTypeTubeContainer from "./components/ChoiceTypeTube/ChoiceTypeTubeContainer";
import ResultSectionContainer from "./components/ResultSection/ResultSectionContainer";
import ChoiceLengContainer from "./components/ChoiceLengSection/ChoiceLengContainer";
import BaseButton from "./UI_PureComponents/BaseButton";
import "./styles.css";

export default function App() {
  return (
    <div className="wrapper">
      <div className="mainMenu">
        <BlockTubesContainer />
        {/* {если создан блок 1, то создать второй} */}
      </div>
      <hr className="hr"></hr>
      <ChoiceLengContainer />
      <ChoiceTypeTubeContainer />
      <ResultSectionContainer />
      <hr className="hr"></hr>
    </div>
  );
}

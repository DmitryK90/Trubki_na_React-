import react from "react";
import style from "./BaseSelect.module.css";
import imgTr from "../../../public/Img/treug1.png";

//через props можно менять длину и высоту select(style={{ width: "180px", height: '25px' }})
//img прикреплён к правой стороне, и отцентрирован вертикально, при изм.размеров select проблем быть не должно.
const BaseSelect = ({
  array,
  updateValue,
  width = "160px",
  height = "25px",
}) => {
  const update = (e) => {
    updateValue(e.target.value);
  };
  return (
    <div className={style.container}>
      <div className={style.selOne}>
        <select
          onChange={update}
          className={style.leng}
          style={{ width, height }}
        >
          {array.map((item) => (
            <option value={item.value} key={item.value}>
              {item.name}
            </option>
          ))}
        </select>
        <img src={imgTr} alt="" className={style.img1} />
      </div>
    </div>
  );
};

export default BaseSelect;
// style={{ width: "70px" }} внутри select писать.
// style={{ width: props.width }} так наверно из пропсов.
// сравнить все css из этого стиля с компонентами SelectChoiceType, и длину и ещё что-то возможно вынести
// и обьъединить все в один select.

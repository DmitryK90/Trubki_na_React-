import React from "react";
import { connect } from "react-redux";
import BlockTube from "./BlockTube";
import BlockAddContainer from "../BlockAdd/BlockAddContainer";

const BlockTubesContainer = ({
  isCompletedBlockOne,
  name,
  ReadyOne,
  ReadyTwo,
  ReadyThree,
  ReadyFour,
  ReadyFive,
  ReadySix,
}) => {
  return (
    <>
      <BlockTube name={name.tubeOne} num={1} />
      {ReadyOne && <BlockTube name={name.tubeTwo} num={2} />}
      {ReadyTwo && <BlockTube name={name.tubeThree} num={3} />}
      {ReadyThree && <BlockTube name={name.tubeFour} num={4} />}
      {ReadyFour && <BlockTube name={name.tubeFive} num={5} />}
      {ReadyFive && <BlockTube name={name.tubeSix} num={6} />}
      {!ReadyFive && (
        <BlockAddContainer isCompletedBlockOne={isCompletedBlockOne} />
      )}
    </>
  ); // дописать чтобы убирался блок добавить при ReadySix = true.
};
// isCompletedBlockOne(Two...): true; (все поля первого блока проводов заполнены, к ним привязан disabled у
// кнопки 'Добавить'), за тим параметром следят Thunk-функции(двойной dispatch, второй проверяет все поля блока).
// ReadyOne(Two...); (если isCompletedBlockOne(см.выше): true, тогда при клике на кнопку 'Добавить' меняется
// значение в state ReadyOne на true, компонента BlockTubesContainer подписана на обновление ReadyOne из
// сразу же перерисуется с добавлением нового блока)

let mapStateToProps = (state) => {
  return {
    isCompletedBlockOne: state.TubesReducer.blockOne.isCompletedBlockOne,
    ReadyOne: state.TubesReducer.addNewTube.ReadyOne,
    ReadyTwo: state.TubesReducer.addNewTube.ReadyTwo,
    ReadyThree: state.TubesReducer.addNewTube.ReadyThree,
    ReadyFour: state.TubesReducer.addNewTube.ReadyFour,
    ReadyFive: state.TubesReducer.addNewTube.ReadyFive,
    ReadySix: state.TubesReducer.addNewTube.ReadySix,
    name: state.TubesReducer.tubeNames,
  };
};

export default connect(mapStateToProps, null)(BlockTubesContainer);

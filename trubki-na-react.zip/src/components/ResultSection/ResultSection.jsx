import react from "react";
import style from "./ResultSection.module.css";

const ResultSection = () => {
  return (
    <>
      <button className={style.btnCalc}>Рассчитать</button>;
      <p className={style.outResult}></p>
    </>
  );
};

export default ResultSection;

import BlockTubesContainer from "./components/BlockMain/BlockTubesContainer";
import BlockResultContainer from "./components/BlockResult/BlockResultContainer";
import "./styles.css";

export default function App() {
  return (
    <div className="wrapper">
      <div className="mainMenu">
        <BlockTubesContainer />
      </div>
      <hr className="hr"></hr>
      <BlockResultContainer />
      <hr className="hr"></hr>
    </div>
  );
}

import { connect } from "react-redux";
import BlockMain from "./BlockMain";
// import { updateSelectCreator } from "../../actionCreators";

let mapStateToProps = (state) => {};

let mapDispatchToProps = (dispatch) => {
  return {
    updateSelect: (val) => {
      dispatch({ type: "sel1", value: val });
      // dispatch(updateSelectCreator(val)); // диспатчим action объект.
    },
  };
};

const BlockMainContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(BlockMain);

export default BlockMainContainer;

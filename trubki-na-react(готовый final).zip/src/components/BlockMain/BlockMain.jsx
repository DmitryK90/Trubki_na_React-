import react from "react";
import style from "./BlockMain.module.css";
import imgTr from "../../../public/Img/treug1.png";
import InputAmountWireContainer from "../InputAmountWire/InputAmountWireContainer";
import SelectChoiceTypeContainer from "../SelectChoiceType/SelectChoiceTypeContainer";
import SelectChoiceSechContainer from "../SelectChoiceSech/SelectChoiceSechContainer";

function BlockMain(props) {
  return (
    <div className={style.block1}>
      <p className={style.titleBlock}>Провод №1</p>
      <SelectChoiceTypeContainer />
      <SelectChoiceSechContainer />
      <InputAmountWireContainer />
    </div>
  );
}

export default BlockMain;

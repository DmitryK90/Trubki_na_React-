import react from "react";
import style from "./SelectChoiceType.module.css";
import imgTr from "../../../public/Img/treug1.png";

const SelectChoiceType = (props) => {
  // console.log(props.isCompletedTypeOne); //значение value из первого типа.
  console.log("Final - " + props.isCompletedBlockOne); //если все поля введены будет true.
  // console.log(props.stateCompletedReducer);
  let funcChange1 = (e) => {
    let newValue = e.target.value; // 1, 2, 3...
    props.updateSelectTypeValue(newValue, props.stateCompletedReducer); //ВОЗМ УБРАТЬ 2ОЙ АРГ.
  };
  return (
    <>
      <select onChange={funcChange1} className={style.selectType}>
        {props.arrType.map((item) => (
          <option value={item.id} key={item.id}>
            {item.title}
          </option>
        ))}
      </select>
      <img src={imgTr} className={style.img1} />
    </>
  ); //   // arrType - массив объектов с типами проводов.
};

export default SelectChoiceType;

// type: [
//   { id: "", title: "- Тип -" }, // id: "" - при повторном выборе string 0 даст true.
//   { id: 1, title: "МГТФЭ" },
//   { id: 2, title: "МГТФЭ" },
//   { id: 3, title: "МГШВ" },
//   { id: 4, title: "МГШВЭ" },
//   { id: 5, title: "МПО" },
//   { id: 6, title: "МПОЭ" },
//   { id: 7, title: "ПВ3" },
//   { id: 8, title: "МС 16-13" },
//   { id: 9, title: "МСЭ 16-13" },
// ],

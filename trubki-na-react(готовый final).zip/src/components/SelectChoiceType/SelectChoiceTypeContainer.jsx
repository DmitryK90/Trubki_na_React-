import SelectChoiceType from "./SelectChoiceType";
import { connect } from "react-redux";
import { updateSelectTypeValueAC } from "../../Redux/SelectTypeReducer";
import { changeBlockOneTypeThunk } from "../../Redux/CompletedReducer";

let mapStateToProps = (state) => {
  return {
    arrType: state.SelectTypeReducer.type, // массив типов проводов.
    valueWireOne: state.SelectTypeReducer.valueWireOne, // значение(id) типа провода.
    isCompletedTypeOne: state.CompletedReducer.TypeOne, // в state
    isCompletedBlockOne: state.CompletedReducer.isCompletedBlockOne, // для теста
  };
};

let mapDispatchToProps = (dispatch) => {
  return {
    updateSelectTypeValue: (newValue) => {
      dispatch(updateSelectTypeValueAC(newValue)), // диспатчим в SelectTypeReducer.
        dispatch(changeBlockOneTypeThunk(newValue)); // диспатчим в CompletedReducer. (state.CompletedReducer) часть передаём.
    },
  };
};

let SelectChoiceTypeContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(SelectChoiceType);
export default SelectChoiceTypeContainer;

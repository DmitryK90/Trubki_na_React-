import react from "react";
import style from "./SelectChoiceSech.module.css";
import imgTr from "../../../public/Img/treug1.png";

const SelectChoiceSech = (props) => {
  console.log("Final - " + props.isCompletedBlockOne);
  let valueWireOneH = props.valueWireOne;
  let arrSech = props.arrSech;

  let funcChange = (e) => {
    let newValue = e.target.value;
    props.updateSelectSechValue(newValue);
  };

  let reset = () => {
    if (valueWireOneH !== "0") {
      // при занулении(нажатии на тип(-Тип-) valueWireOne становится = '0'), т.е если провод выбран, то отрис. сечения.
      return arrSech
        .filter((item) => item.prId_1 == valueWireOneH)
        .map((items) => (
          <option value={items.sechId_1} key={items.id}>
            {items.title}
          </option>
        ));
    } else {
      // если провод выбран на '-Тип-', то зануляем valueWireOne == '', далее в input-у проверяется оба знач на true, и присваиваем valueWireOne = "Кол-во."
      return props.updateSelectSechValue("");
    }
  };

  return (
    <>
      <select
        onChange={funcChange}
        className={style.selectType}
        disabled={
          props.valueWireOne !== "" && props.valueWireOne !== "0" ? false : true
        }
      >
        <option value=""> - Сечение -</option>
        {reset()}
      </select>
      <img src={imgTr} className={style.img2} />
    </>
  );
};

export default SelectChoiceSech;

// {props.arrSech
//   .filter((item) => item.prId_1 == props.valueWireOne)
//   .map((items) => (
//     <option value={items.sechId_1} key={items.id}>
//       {items.title}
//     </option>
//   ))}

import react from "react";
import SelectChoiceSech from "./SelectChoiceSech";
import { updateSelectSechValueAC } from "../../Redux/SelectSechReducer";
import { changeBlockOneSechThunk } from "../../Redux/CompletedReducer";
import { connect } from "react-redux";

let mapStateToProps = (state) => {
  return {
    arrSech: state.SelectSechReducer.sech, // массив с сечениями проводов.
    valueSechOne: state.SelectSechReducer.valueSechOne, // значение(sechId_1) сечения.
    valueWireOne: state.SelectTypeReducer.valueWireOne, // значение(id) типа провода.
    isCompletedBlockOne: state.CompletedReducer.isCompletedBlockOne, // для теста
  };
};

let mapDispatchToProps = (dispatch) => {
  return {
    updateSelectSechValue: (newValue) => {
      dispatch(updateSelectSechValueAC(newValue));
      dispatch(changeBlockOneSechThunk(newValue));
    },
  };
};

let SelectChoiceSechContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(SelectChoiceSech);
export default SelectChoiceSechContainer;

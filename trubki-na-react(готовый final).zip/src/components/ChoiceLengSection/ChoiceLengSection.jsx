import react from "react";
import style from "./ChoiceLengSection.module.css";
import imgTr from "../../../public/Img/treug1.png";

const ChoiceLengSection = () => {
  return (
    <div className={style.choice_L}>
      <div className={style.selOne}>
        <select className={style.leng} name="leng">
          <option value="0">- Длина провода -</option>
          <option value="2.0">До 3 метров</option>
          <option value="2.2">От 3 до 10 метров</option>
          <option value="2.4">От 10 метров</option>
        </select>
        <img src={imgTr} alt="" className={style.img1} />
      </div>
      <div className={style.selTwo}>
        <select className={style.leng1} name="leng">
          <option value="0">- Тип трубки -</option>
          <option value="ТВ-40">305ТВ-40</option>
          <option value="ТВ-40Т">305ТВ-40Т</option>
          <option value="ТВ-40А">305ТВ-40А</option>
          <option value="ТВ-50">305ТВ-50</option>
          <option value="ТВ-50-14">305ТВ-50-14</option>
          <option value="ТВ-60">305ТВ-60</option>
          <option value="Deray IAKT 3:1">Deray IAKT 3:1</option>
          <option value="Deray IAKT 4:1">Deray IAKT 4:1</option>
          <option value="Deray HB">Deray HB</option>
        </select>
        <img src={imgTr} alt="" className={style.img1} />
        <button className={style.btn_info} title="Помощь в выборе трубки.">
          ?
        </button>
      </div>
    </div>
  );
};

export default ChoiceLengSection;

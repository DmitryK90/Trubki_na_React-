import react from "react";
import InputAmountWire from "./InputAmountWire";
import { updateAmountWireAC } from "../../Redux/InputReducer";
import { changeBlockOneInputThunk } from "../../Redux/CompletedReducer";
import { connect } from "react-redux";

let mapStateToProps = (state) => {
  return {
    // amountWireOne: state.InputReducer.amountWireOne, // сюда приходит кол-во проводов из первого блока input.s
    amountWireOne: state.CompletedReducer.InputOne, // сюда приходит кол-во проводов из первого блока input.s
    valueWireOne: state.SelectTypeReducer.valueWireOne, // значение(id) типа провода.
    valueSechOne: state.SelectSechReducer.valueSechOne, // значение(sechId_1) сечения.
    isCompletedBlockOne: state.CompletedReducer.isCompletedBlockOne, // для теста
  };
};

let mapDispatchToProps = (dispatch) => {
  return {
    updateAmountWire: (newValue) => {
      // dispatch(updateAmountWireAC(newValue));
      dispatch(changeBlockOneInputThunk(newValue));
    },
  };
};

const InputAmountWireContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(InputAmountWire);
export default InputAmountWireContainer;

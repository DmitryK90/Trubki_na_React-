import react from "react";
import style from "./InputAmountWire.module.css";

const InputAmountWire = (props) => {
  console.log("Final - " + props.isCompletedBlockOne); //если все поля введены будет true.
  let val = props.amountWireOne;

  if (val < 1) {
    props.updateAmountWire("");
  } else if (val > 50) {
    props.updateAmountWire("");
  } else {
    props.updateAmountWire(val);
  } // ВСЁ РАБОТАЕТ! ОТ 1 ДО 50 МОЖНО ВВОДИТЬ ТОЛЬКО.

  let funcChange = (e) => {
    let value = e.target.value; // знач.пришходит.
    props.updateAmountWire(value);
  };

  let resetValue = (val) => {
    props.updateAmountWire(val);
    return props.amountWireOne;
  };

  return (
    <input
      className={style.inputNum}
      onChange={funcChange}
      value={
        props.valueSechOne && props.valueWireOne //props.valueSechOne(''-def, ''-повт.) props.valueWireOne(''-def, ''-повт.)
          ? props.amountWireOne
          : resetValue("Кол-во.")
      }
      type="number"
      disabled={
        props.valueSechOne !== "" &&
        props.valueWireOne !== "" &&
        props.valueWireOne !== "0"
          ? false
          : true
      }
      placeholder="Кол-во."
    ></input>
  );
};

export default InputAmountWire;

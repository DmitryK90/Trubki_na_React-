import react from "react";
import style from "./BlockAdd.module.css";

const BlockAdd = () => {
  return (
    <div className={style.wrapper}>
      <div className={style.blockAdd}>
        <button type="button" className={style.btnBigAdd}>
          Добавить
        </button>
      </div>
    </div>
  );
};

export default BlockAdd;

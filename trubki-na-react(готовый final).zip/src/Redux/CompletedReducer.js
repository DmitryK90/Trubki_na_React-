const IS_COMPLETED_TYPE_ONE = "IS_COMPLETED_TYPE_ONE";
const IS_COMPLETED_SECH_ONE = "IS_COMPLETED_SECH_ONE";
const IS_COMPLETED_INPUT_ONE = "IS_COMPLETED_INPUT_ONE";
const IS_COMPLETED_BLOCK_ONE = "IS_COMPLETED_BLOCK_ONE";

const initialState = {
  // ПЕРЕПИСАТЬ ИМЕНА ПЕРЕМЕННЫХ НА БОЛЕЕ ПОНЯТНЫЕ И КОРОТКИЕ И РАЗБИТЬ ПО ПОДЪОБЪЕКТАМ!
  // blockOne: {
  TypeOne: false, // селект типа перв.блока заполнен. Должно прийти ЗНАЧЕНИЕ!
  SechOne: false, // селект сечений перв.блока заполнен. Должно прийти ЗНАЧЕНИЕ!
  InputOne: false, // кол-во пров. перв.блока заполнено. Должно прийти ЗНАЧЕНИЕ!
  isCompletedBlockOne: false, // все поля ввода перв.блока заполнены.
  // },
  BlockTwo: {}, // второй блок.
};

export function CompletedReducer(state = initialState, action) {
  switch (action.type) {
    case IS_COMPLETED_TYPE_ONE: // изменяем тип первого провода.
      return {
        ...state,
        TypeOne: action.newValue,
      }; // изменяем тип.
    case IS_COMPLETED_SECH_ONE: // изменяем сечение первого провода.
      return {
        ...state,
        SechOne: action.newValue,
      };
    case IS_COMPLETED_INPUT_ONE:
      return {
        ...state,
        InputOne: action.newValue,
      };
    case IS_COMPLETED_BLOCK_ONE: // проверка на заполненность трёх полей данных.
      const { TypeOne, SechOne, InputOne } = state; // вытаскиваем TypeOne из state, чтобы могли обратиться.
      // debugger;
      if (TypeOne && SechOne && InputOne !== "Кол-во." && InputOne !== "") {
        // попробовать сделать нулевой option не 0, а пустой строкой, чтобы удобней все 3 компановать было потом.
        return {
          ...state,
          isCompletedBlockOne: true,
        };
      } else {
        return {
          ...state,
          isCompletedBlockOne: false,
        };
      }
    default:
      return state;
  }
}
// ----- actionCreators -----
const isCompletedTypeOneAC = (newValue) => {
  return {
    type: IS_COMPLETED_TYPE_ONE,
    newValue,
  };
};
const isCompletedSechOneAC = (newValue) => {
  return {
    type: IS_COMPLETED_SECH_ONE,
    newValue,
  };
};
const isCompletedInputOneAC = (newValue) => {
  return {
    type: IS_COMPLETED_INPUT_ONE,
    newValue,
  };
};

const isCompletedBlockOneAC = (
  TypeOne,
  SechOne,
  InputOne,
  isCompletedBlockOne
) => {
  return {
    type: IS_COMPLETED_BLOCK_ONE,
    TypeOne,
    SechOne,
    InputOne,
    isCompletedBlockOne,
  };
  // }
};

// ----- thunk -----
export const changeBlockOneTypeThunk = (newValue) => {
  return (dispatch, getState) => {
    const { TypeOne, SechOne, InputOne, isCompletedBlockOne } = getState();
    // обращаемся к нашему state и деструктуризируем, чтобы проверить заполненность полей.
    // можно после рефакторинга передавать часть state этого блока, state.blockOne как-то так.
    dispatch(isCompletedTypeOneAC(newValue)); // изменяем value селекта 'типа' перв.блока.
    dispatch(
      isCompletedBlockOneAC(TypeOne, SechOne, InputOne, isCompletedBlockOne)
    );
    //интересно, мы запрашиваем state перед первый dispatch, поидее во втором должен быть старый state, но все норм.
  };
}; // всё работает!

export const changeBlockOneSechThunk = (newValue) => {
  return (dispatch, getState) => {
    const { TypeOne, SechOne, InputOne, isCompletedBlockOne } = getState();
    dispatch(isCompletedSechOneAC(newValue));
    dispatch(
      isCompletedBlockOneAC(TypeOne, SechOne, InputOne, isCompletedBlockOne)
    ); // доработать проверку, одна во всех должна быть.
  };
};

export const changeBlockOneInputThunk = (newValue) => {
  return (dispatch, getState) => {
    const { TypeOne, SechOne, InputOne, isCompletedBlockOne } = getState();
    dispatch(isCompletedInputOneAC(newValue));
    dispatch(
      isCompletedBlockOneAC(TypeOne, SechOne, InputOne, isCompletedBlockOne)
    );
  };
};

export default CompletedReducer;

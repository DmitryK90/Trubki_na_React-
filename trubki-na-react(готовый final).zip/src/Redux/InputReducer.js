const UPDATE_AMOUNT_WIRE = "UPDATE_AMOUNT_WIRE";

const initialState = {
  amountWireOne: "", // сюда приходит кол-во проводов из первого блока input.
  amountWireTwo: "",
  amountWireThree: "",
  amountWireFour: "",
  amountWireFive: "",
  amountWireSix: "",
};

export function InputReducer(state = initialState, action) {
  switch (action.type) {
    case UPDATE_AMOUNT_WIRE:
      return {
        ...state,
        amountWireOne: action.number,
      };
    // case "ACTION_2":
    //   return { value: action.value_2 };

    default:
      return state;
  }
}

export const updateAmountWireAC = (number) => {
  return {
    type: UPDATE_AMOUNT_WIRE,
    number: number,
  };
};

import { combineReducers, legacy_createStore, applyMiddleware } from "redux";
import { InputReducer } from "./InputReducer";
import { SelectTypeReducer } from "./SelectTypeReducer";
import { SelectSechReducer } from "./SelectSechReducer";
import { CompletedReducer } from "./CompletedReducer";
import { thunk } from "redux-thunk";

let reducers = combineReducers({
  InputReducer,
  SelectTypeReducer,
  SelectSechReducer,
  CompletedReducer,
});

let store = legacy_createStore(reducers, applyMiddleware(thunk));

export default store;

const UPDATE_SELECT_TYPE_VALUE = "UPDATE_SELECT_TYPE_VALUE";

const initialState = {
  valueWireOne: "", // приходит по сути id (0,1,2,3...)
  isCompletedWireOne: false, // если valueWireOne(тип провода заполнен) true, тогда true. Хотя valueWireOne и так true даст если будет какое-то значение.
  valueWireTwo: "",
  valueWireThree: "",
  valueWireFour: "",
  valueWireFive: "",
  valueWireSix: "",
  type: [
    { id: 0, title: "- Тип -" }, // id: "" - при повторном выборе string 0 даст true.
    { id: 1, title: "МГТФЭ" },
    { id: 2, title: "МГТФЭ" },
    { id: 3, title: "МГШВ" },
    { id: 4, title: "МГШВЭ" },
    { id: 5, title: "МПО" },
    { id: 6, title: "МПОЭ" },
    { id: 7, title: "ПВ3" },
    { id: 8, title: "МС 16-13" },
    { id: 9, title: "МСЭ 16-13" },
  ],
};

export function SelectTypeReducer(state = initialState, action) {
  switch (action.type) {
    case UPDATE_SELECT_TYPE_VALUE:
      return {
        ...state,
        valueWireOne: action.newValue,
        isCompletedWireOne: action.isCompleted,
      };
    default:
      return state;
  }
}

export let updateSelectTypeValueAC = (newValue) => {
  return {
    type: UPDATE_SELECT_TYPE_VALUE,
    newValue,
  };
};

// export let updateSelectTypeValueAC = (newValue) => {
//   if (newValue !== "0") {
//     return {
//       type: UPDATE_SELECT_TYPE_VALUE,
//       newValue,
//       isCompleted: true,
//     };
//   } else {
//     return {
//       type: UPDATE_SELECT_TYPE_VALUE,
//       newValue,
//       isCompleted: false,
//     };
//   }
// }; //работает

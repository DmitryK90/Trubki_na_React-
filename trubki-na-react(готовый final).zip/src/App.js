import BlockMainContainer from "./components/BlockMain/BlockMainContaiter";
import ChoiceLengSection from "./components/ChoiceLengSection/ChoiceLengSection";
import ResultSection from "./components/ResultSection/ResultSection";
import BlockAdd from "./components/BlockAdd/BlockAdd";
import "./styles.css";

export default function App() {
  return (
    <div className="wrapper">
      <div className="mainMenu">
        <BlockMainContainer />
        {/* {если создан блок 1, то создать второй} */}
        <BlockAdd />
      </div>
      <hr className="hr"></hr>
      <ChoiceLengSection />
      <ResultSection />
      <hr className="hr"></hr>
    </div>
  );
}
